    var pic = document.querySelector('#pic');
    
		function changePic() {			
			pic.src = "images/boy.png";
    }
    function drawBorder() {
      pic.style.border = "2px dotted #666";
    }